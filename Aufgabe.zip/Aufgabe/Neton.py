from Weton import*
from Hari import*
Hari = Day_Determine #Method
Weton = Weton_Determine #Method
Parameter1 = 0
Parameter2 = 0
if Hari == "Minggu":
    Parameter1 = 5
elif Hari == "Senin":
    Parameter1 = 4
elif Hari == "Selasa":
    Parameter1 = 3
elif Hari == "Rabu":
    Parameter1 = 7
elif Hari == "Kamis":
    Parameter1 = 8
elif Hari == "Jumat":
    Parameter1 = 6
elif Hari == "Sabtu":
    Parameter1 = 9

if Weton == "Legi":
    Parameter2 = 5
elif Weton == "Pahing":
    Parameter2 = 9
elif Weton == "Pon":
    Parameter2 = 7
elif Weton == "Wage":
    Parameter2 = 4
elif Weton == "Kliwon":
    Parameter2 = 8

Parameter3 = (Parameter1 + Parameter2)%9
if Parameter3 == 0:
    print("Pegat")
elif Parameter3 == 1:
    print("Pegat")
elif Parameter3 == 2:
    print("Ratu")
elif Parameter3 == 3:
    print("Jodoh")
elif Parameter3 == 4:
    print("Topo")
elif Parameter3 == 5:
    print("Tinari")
elif Parameter3 == 6:
    print("Padu")
elif Parameter3 == 7:
    print("Sujanan")
elif Parameter3 == 8:
    print("Pesthi")

