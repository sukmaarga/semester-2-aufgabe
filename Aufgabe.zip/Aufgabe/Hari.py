#Day Search
Tanggal = 1
Tahun = 1901
Januari = 0
Februari = 3
Maret = 3
April = 6
Mei = 1
Juni = 4
July = 6
Agustus = 2
September = 5
Oktober = 0
November = 3
Desember = 5
Day_Determine = ""
if Tahun%4 == 0 and Tahun%400 == 0:
    Januari = 6
    Februari = 2
elif Tahun % 4 == 0 and Tahun%100 !=0 :
    Januari = 6
    Februari = 2
Bulan = 0 #get oop
Day_Determine = int((Tahun+(Tahun/4)+Tanggal+Bulan)%7) #harus get Bulan yg mnggnukan equivalent
if Day_Determine == 0 :
    Day_Determine = "Jumat"
    print("Friday")
elif Day_Determine == 1 :
    Day_Determine = "Sabtu"
    print("Satruday")
elif Day_Determine == 2 :
    Day_Determine = "Minggu"
    print("Sunday")
elif Day_Determine == 3 :
    Day_Determine = "Senin"
    print("Monday")
elif Day_Determine == 4 :
    Day_Determine = "Selasa"
    print("Tuesday")
elif Day_Determine == 5 :
    Day_Determine = "Rabu"
    print("Wednesday")
elif Day_Determine == 6 :
    Day_Determine = "Kamis"
    print ("Thursday")