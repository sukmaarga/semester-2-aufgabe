from Operation import*
Date = int(input("Input Born Date"))
Month = int(input("Input Born Month"))
Year = int(input("Input Born Year"))

User = Weton(Date, Month, Year)
User.Weton_Rechner()
User.Hari()
User.Neton()
