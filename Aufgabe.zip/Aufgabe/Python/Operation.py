from datetime import datetime
class Weton():
    def __init__(self, Date, Month, Year):
        self.Date_int = Date
        self.Month_int = Month
        self.Year_int = Year
    def Weton_Rechner(self):
        Date_Format = "%d/%m/%Y"
        Date = str(self.Date_int)
        Month = str(self.Month_int)
        Year = str(self.Year_int)
        Dmy = Date + "/" + Month + "/" + Year
        Base_Born = datetime.strptime('1/1/1901', Date_Format)
        Person_Born = datetime.strptime(Dmy, Date_Format)
        Many_Days = (int((Person_Born - Base_Born).days) + 1) % 5
        self.Weton_Determine = ""
        if Many_Days == 0:
            self.Weton_Determine = "Legi"
            print("Legi")
        elif Many_Days == 1:
            self.Weton_Determine = "Pahing"
            print("Pahing")
        elif Many_Days == 2:
            self.Weton_Determine = "Pon"
            print("Pon")
        elif Many_Days == 3:
            self.Weton_Determine = "Wage"
            print("Wage")
        elif Many_Days == 4:
            self.Weton_Determine = "Kliwon"
            print("Kliwon")
    def Hari(self):
        Month2 = self.Month_int
        if Month2 == 1 :
            Month2 = 0
            if self.Year_int % 4 == 0 and self.Year_int % 400 == 0:
                Month2 = 6
            elif self.Year_int % 4 == 0 and self.Year_int % 100 != 0:
                Month2 = 6
        elif Month2 == 2 :
            Month2 = 3
            if self.Year_int % 4 == 0 and self.Year_int % 400 == 0:
                Month2 = 2
            elif self.Year_int % 4 == 0 and self.Year_int % 100 != 0:
                Month2 = 2
        elif Month2 == 3 :
            Month2 = 3
        elif Month2 == 4 :
            Month2 = 6
        elif Month2 == 5 :
            Month2 = 1
        elif Month2 == 6 :
            Month2 = 4
        elif Month2 == 7 :
            Month2 = 6
        elif Month2 == 8 :
            Month2 = 2
        elif Month2 == 9 :
            Month2 = 5
        elif Month2 == 10 :
            Month2 = 0
        elif Month2 == 11 :
            Month2 = 3
        elif Month2 == 12:
            Month2 = 5
        self.Day_Determine = ""
        self.Day_Determine = int((self.Year_int + (self.Year_int / 4) + self.Date_int + Month2) % 7)  # harus get Bulan yg mnggnukan equivalent
        if self.Day_Determine == 0:
            self.Day_Determine = "Friday"
            print("Friday")
        elif self.Day_Determine == 1:
            self.Day_Determine = "Satruday"
            print("Satruday")
        elif self.Day_Determine == 2:
            self.Day_Determine = "Sunday"
            print("Sunday")
        elif self.Day_Determine == 3:
            self.Day_Determine = "Monday"
            print("Monday")
        elif self.Day_Determine == 4:
            self.Day_Determine = "Tuesday"
            print("Tuesday")
        elif self.Day_Determine == 5:
            self.Day_Determine = "Wednesday"
            print("Wednesday")
        elif self.Day_Determine == 6:
            self.Day_Determine = "Thursday"
            print("Thursday")

    def Neton(self) :
        Hari = self.Day_Determine  # Method
        Java_Date = self.Weton_Determine  # Method
        Parameter1 = 0
        Parameter2 = 0
        if Hari == "Sunday":
            Parameter1 = 5
        elif Hari == "Monday":
            Parameter1 = 4
        elif Hari == "Tuesday":
            Parameter1 = 3
        elif Hari == "Wednesday":
            Parameter1 = 7
        elif Hari == "Thursday":
            Parameter1 = 8
        elif Hari == "Friday":
            Parameter1 = 6
        elif Hari == "Saturday":
            Parameter1 = 9

        if Java_Date == "Legi":
            Parameter2 = 5
        elif Weton == "Pahing":
            Parameter2 = 9
        elif Weton == "Pon":
            Parameter2 = 7
        elif Weton == "Wage":
            Parameter2 = 4
        elif Weton == "Kliwon":
            Parameter2 = 8

        Parameter3 = (Parameter1 + Parameter2) % 9
        if Parameter3 == 0:
            print("Pegat")
        elif Parameter3 == 1:
            print("Pegat")
        elif Parameter3 == 2:
            print("Ratu")
        elif Parameter3 == 3:
            print("Jodoh")
        elif Parameter3 == 4:
            print("Topo")
        elif Parameter3 == 5:
            print("Tinari")
        elif Parameter3 == 6:
            print("Padu")
        elif Parameter3 == 7:
            print("Sujanan")
        elif Parameter3 == 8:
            print("Pesthi")

User = Weton(29,1,1999)