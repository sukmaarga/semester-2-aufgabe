#Weton Search
from datetime import datetime
Date_Format = "%d/%m/%Y"
Date = "22"
Month = "4"
Year = "1998"
Dmy = Date+"/"+Month+"/"+Year
Base_Born = datetime.strptime('1/1/1901',Date_Format)
Person_Born = datetime.strptime(Dmy ,Date_Format)
Many_Days = (int((Person_Born - Base_Born).days)+1)%5
Weton_Determine = ""
if Many_Days == 0:
    Weton_Determine = "Legi"
    print("Legi")
elif Many_Days == 1 :
    Weton_Determine = "Pahing"
    print("Pahing")
elif Many_Days == 2 :
    Weton_Determine = "Pon"
    print("Pon")
elif Many_Days == 3 :
    Weton_Determine = "Wage"
    print("Wage")
elif Many_Days == 4 :
    Weton_Determine = "Kliwon"
    print("Kliwon")